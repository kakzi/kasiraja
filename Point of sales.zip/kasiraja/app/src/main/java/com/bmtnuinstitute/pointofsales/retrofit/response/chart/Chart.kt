package com.bmtnuinstitute.pointofsales.retrofit.response.chart

data class Chart(
    val `data`: String,
    val nama_bulan: String
)