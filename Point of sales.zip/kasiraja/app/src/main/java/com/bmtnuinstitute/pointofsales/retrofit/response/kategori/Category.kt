package com.bmtnuinstitute.pointofsales.retrofit.response.kategori

data class Category(
    val created_at: String,
    val deleted_at: Any,
    val id_kategori: String,
    val nama_kategori: String,
    val updated_at: String
)