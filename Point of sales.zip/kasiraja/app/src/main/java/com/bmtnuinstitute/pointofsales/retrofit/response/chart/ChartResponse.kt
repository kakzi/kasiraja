package com.bmtnuinstitute.pointofsales.retrofit.response.chart

data class ChartResponse(
    val `data`: List<Chart>,
    val error: Boolean
)