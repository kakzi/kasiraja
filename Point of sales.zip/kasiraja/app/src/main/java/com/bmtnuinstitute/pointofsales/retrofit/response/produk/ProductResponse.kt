package com.bmtnuinstitute.pointofsales.retrofit.response.produk

class ProductResponse : ArrayList<Product>()