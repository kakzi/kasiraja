package com.bmtnuinstitute.pointofsales.retrofit.response.produk

data class AddProductResponse(
    val error: Boolean,
    val message: String
)