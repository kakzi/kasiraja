package com.bmtnuinstitute.pointofsales.retrofit.response.dashboard


data class Omset (
    val error : Boolean,
    val data : List<OmsetResponse>
)