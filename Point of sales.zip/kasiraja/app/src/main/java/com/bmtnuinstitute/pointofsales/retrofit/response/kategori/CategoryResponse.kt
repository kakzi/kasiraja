package com.bmtnuinstitute.pointofsales.retrofit.response.kategori

class CategoryResponse : ArrayList<Category>()