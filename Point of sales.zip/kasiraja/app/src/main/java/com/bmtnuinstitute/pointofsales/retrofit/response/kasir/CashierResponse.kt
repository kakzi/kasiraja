package com.bmtnuinstitute.pointofsales.retrofit.response.kasir

data class CashierResponse(
    val `data`: List<Cashier>,
    val error: Boolean
)