package com.bmtnuinstitute.pointofsales.retrofit.response.keranjang

class CartResponse : ArrayList<Cart>()