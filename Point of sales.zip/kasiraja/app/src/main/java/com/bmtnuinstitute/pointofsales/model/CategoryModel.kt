package com.bmtnuinstitute.pointofsales.model

data class CategoryModel (val title: String)