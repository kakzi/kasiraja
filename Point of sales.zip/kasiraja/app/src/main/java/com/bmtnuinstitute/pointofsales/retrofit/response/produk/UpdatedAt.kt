package com.bmtnuinstitute.pointofsales.retrofit.response.produk

data class UpdatedAt(
    val date: String,
    val timezone: String,
    val timezone_type: Int
)