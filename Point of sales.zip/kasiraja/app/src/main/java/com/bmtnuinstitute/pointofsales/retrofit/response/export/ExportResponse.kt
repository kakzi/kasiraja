package com.bmtnuinstitute.pointofsales.retrofit.response.export

data class ExportResponse(
    val `data`: String,
    val error: Boolean
)