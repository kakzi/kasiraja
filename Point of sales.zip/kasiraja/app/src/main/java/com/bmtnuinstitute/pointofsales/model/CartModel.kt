package com.bmtnuinstitute.pointofsales.model

data class CartModel (val title: String, val price: Int, val image: Int, var qty: Int, var total: Int)