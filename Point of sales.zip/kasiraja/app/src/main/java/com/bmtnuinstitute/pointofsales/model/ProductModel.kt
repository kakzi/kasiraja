package com.bmtnuinstitute.pointofsales.model

data class ProductModel (val title: String)