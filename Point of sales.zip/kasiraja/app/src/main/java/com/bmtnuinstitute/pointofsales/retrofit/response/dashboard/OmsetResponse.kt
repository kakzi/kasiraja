package com.bmtnuinstitute.pointofsales.retrofit.response.dashboard


data class OmsetResponse (
    val error: Boolean,
    val omset : Int
)