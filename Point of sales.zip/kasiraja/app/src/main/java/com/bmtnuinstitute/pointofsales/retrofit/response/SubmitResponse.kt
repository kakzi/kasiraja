package com.bmtnuinstitute.pointofsales.retrofit.response

data class SubmitResponse(
    val error: Boolean,
    val message: String
)