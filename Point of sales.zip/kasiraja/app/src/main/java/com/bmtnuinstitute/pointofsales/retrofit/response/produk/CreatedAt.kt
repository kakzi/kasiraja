package com.bmtnuinstitute.pointofsales.retrofit.response.produk

data class CreatedAt(
    val date: String,
    val timezone: String,
    val timezone_type: Int
)