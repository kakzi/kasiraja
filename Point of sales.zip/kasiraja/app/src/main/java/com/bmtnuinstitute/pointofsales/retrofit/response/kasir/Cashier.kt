package com.bmtnuinstitute.pointofsales.retrofit.response.kasir

data class Cashier(
    val created_at: String,
    val is_aktif: String,
    val level: String,
    val nama: String,
    val password: String,
    val updated_at: String,
    val username: String
)