package com.bmtnuinstitute.pointofsales.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Menu(val title: String , val image: Int):Parcelable